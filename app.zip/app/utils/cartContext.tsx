import React, { createContext, useContext, useState, ReactNode } from 'react';

type CartItem = {
  id: string;
  nazev: string;
  cena: number;
  množství: number;
  pestitelNazev: string;
  pestitelId: number;
};

type CartContextType = {
  cart: CartItem[];
  addToCart: (item: Omit<CartItem, 'id'> & { id?: string }) => void;
  removeFromCart: (id: string) => void;
  clearCart: () => void;
  totalPrice: number;
};

const CartContext = createContext<CartContextType | undefined>(undefined);

export function CartProvider({ children }: { children: ReactNode }) {
  const [cart, setCart] = useState<CartItem[]>([]);

  const addToCart = (item: Omit<CartItem, 'id'> & { id?: string }) => {
    const newItem: CartItem = {
      id: item.id || `${item.pestitelId}-${item.nazev}-${Date.now()}`,
      nazev: item.nazev,
      cena: item.cena,
      množství: item.množství || 1,
      pestitelNazev: item.pestitelNazev,
      pestitelId: item.pestitelId,
    };

    setCart(prev => {
      const existingIndex = prev.findIndex(i => i.id === newItem.id);
      if (existingIndex >= 0) {
        const updated = [...prev];
        updated[existingIndex].množství += 1;
        return updated;
      }
      return [...prev, newItem];
    });
  };

  const removeFromCart = (id: string) => {
    setCart(prev => prev.filter(item => item.id !== id));
  };

  const clearCart = () => {
    setCart([]);
  };

  const totalPrice = cart.reduce((sum, item) => sum + item.cena * item.množství, 0);

  return (
    <CartContext.Provider value={{ cart, addToCart, removeFromCart, clearCart, totalPrice }}>
      {children}
    </CartContext.Provider>
  );
}

export function useCart() {
  const context = useContext(CartContext);
  if (!context) {
    throw new Error('useCart must be used within CartProvider');
  }
  return context;
}
