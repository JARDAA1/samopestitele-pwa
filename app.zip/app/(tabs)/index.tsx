import { View, Text, StyleSheet, TouchableOpacity, ImageBackground } from 'react-native';
import { router } from 'expo-router';

export default function HomeScreen() {
  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.logo}>🌱</Text>
        <Text style={styles.title}>Samopěstitelé</Text>
        <Text style={styles.subtitle}>Propojujeme pěstitele se zákazníky</Text>
      </View>

      <TouchableOpacity
        style={styles.primaryButton}
        onPress={() => alert('Klikli jste na Prohlédnout pěstitele')}
      >
        <Text style={styles.primaryButtonIcon}>🌱</Text>
        <View>
          <Text style={styles.primaryButtonTitle}>Prohlédnout pěstitele</Text>
          <Text style={styles.primaryButtonSubtitle}>Najděte čerstvé produkty z vaší oblasti</Text>
        </View>
      </TouchableOpacity>

      <TouchableOpacity
        style={styles.secondaryButton}
        onPress={() => alert('Přihlášení pro pěstitele')}
      >
        <Text style={styles.secondaryButtonText}>🔐 Vstup pro pěstitele</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#E8F5E9', justifyContent: 'center', alignItems: 'center', padding: 20 },
  header: { alignItems: 'center', marginBottom: 60 },
  logo: { fontSize: 80, marginBottom: 10 },
  title: { fontSize: 36, fontWeight: '900', color: '#2E7D32', textAlign: 'center', marginBottom: 8 },
  subtitle: { fontSize: 16, color: '#666', textAlign: 'center' },
  primaryButton: { backgroundColor: '#4CAF50', paddingVertical: 24, paddingHorizontal: 30, borderRadius: 20, width: '90%', maxWidth: 400, flexDirection: 'row', alignItems: 'center', marginBottom: 20 },
  primaryButtonIcon: { fontSize: 50, marginRight: 20 },
  primaryButtonTitle: { fontSize: 22, fontWeight: 'bold', color: '#FFFFFF', marginBottom: 4 },
  primaryButtonSubtitle: { fontSize: 14, color: '#FFFFFF', opacity: 0.9 },
  secondaryButton: { backgroundColor: '#FF9800', paddingVertical: 16, paddingHorizontal: 30, borderRadius: 12, width: '90%', maxWidth: 400, alignItems: 'center' },
  secondaryButtonText: { fontSize: 16, fontWeight: '600', color: '#FFFFFF' },
});
